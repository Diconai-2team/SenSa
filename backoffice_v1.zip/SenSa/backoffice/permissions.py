"""
backoffice/permissions.py — 백오피스 진입 권한 게이트

원칙:
  - 백오피스 모든 페이지/API 는 슈퍼관리자만 접근.
  - 비로그인 → 로그인 페이지로 next 파라미터 동반 리다이렉트.
  - 로그인했지만 슈퍼관리자가 아님 → 403 (대시보드로 튕기지 않음 — URL 디버그가 어려워짐).

향후 v2: '관리자' 역할에게도 일부 메뉴 노출 (메뉴 관리 화면 결과 반영).
       지금은 단순 슈퍼관리자 only.
"""
from functools import wraps

from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponseForbidden
from django.shortcuts import render


def super_admin_required(view_func):
    """페이지 뷰용 — 비-슈퍼관리자는 403 페이지."""
    @wraps(view_func)
    @login_required
    def _wrapped(request, *args, **kwargs):
        user = request.user
        if not (user.is_authenticated and user.is_super_admin_role):
            return render(request, 'backoffice/403.html', status=403)
        return view_func(request, *args, **kwargs)
    return _wrapped


def super_admin_required_api(view_func):
    """JSON API 뷰용 — 비-슈퍼관리자는 401/403 JSON."""
    @wraps(view_func)
    def _wrapped(request, *args, **kwargs):
        user = request.user
        if not user.is_authenticated:
            return JsonResponse({'error': 'login_required'}, status=401)
        if not user.is_super_admin_role:
            return JsonResponse({'error': 'forbidden'}, status=403)
        return view_func(request, *args, **kwargs)
    return _wrapped
