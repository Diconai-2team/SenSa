"""
backoffice/forms.py — 사용자/조직/직위 등록·수정 폼

피그마 명세의 validation 메시지를 그대로 반영.
공통 규칙:
  - 미입력  → "X 을(를) 입력해 주세요."
  - 형식 오류 → "X 형식이 올바르지 않습니다." 등
  - 중복     → "이미 사용 중인 X 입니다."
  - 길이 초과 → "X 은 N자 이하로 입력해 주세요."

Trade-off (v1 단순화):
  - 비밀번호 "영문/숫자/특수문자 중 2가지 이상" 규칙은 적용 (피그마 그대로)
  - 사용자명 "한글/영문/숫자만" 규칙 적용
  - 이메일은 Django 기본 EmailValidator + 100자 제한
"""
import re

from django import forms
from django.contrib.auth import get_user_model
from django.core.validators import EmailValidator

from .models import Organization, Position


User = get_user_model()


# ═══════════════════════════════════════════════════════════
# 공통 헬퍼
# ═══════════════════════════════════════════════════════════

USERNAME_RE = re.compile(r'^[A-Za-z0-9가-힣]+$')        # 한글/영문/숫자만
LOGIN_ID_RE = re.compile(r'^[A-Za-z0-9]+$')             # 영문/숫자만
PHONE_RE    = re.compile(r'^\d{2,4}-?\d{3,4}-?\d{4}$')


def _strip_or_blank(value: str | None) -> str:
    return (value or '').strip()


# ═══════════════════════════════════════════════════════════
# 사용자 등록 폼 (모든 필수값 + validation)
# ═══════════════════════════════════════════════════════════

class UserCreateForm(forms.Form):
    """피그마 사용자 등록 모달의 validation 명세를 코드로 옮긴 폼."""

    name           = forms.CharField(required=False)   # 사용자명 (first_name 에 저장)
    username       = forms.CharField(required=False)   # 아이디 (login id)
    password       = forms.CharField(required=False)
    password_check = forms.CharField(required=False)
    organization   = forms.IntegerField(required=False)  # Organization PK
    role           = forms.CharField(required=False)
    position_obj   = forms.IntegerField(required=False)  # Position PK
    account_status = forms.CharField(required=False)   # 'active' | 'disabled'
    email          = forms.CharField(required=False)
    phone          = forms.CharField(required=False)

    # ── 사용자명 (=name, first_name 에 저장) ──
    def clean_name(self):
        v = _strip_or_blank(self.cleaned_data.get('name'))
        if not v:
            raise forms.ValidationError('사용자명을 입력해 주세요.')
        if len(v) < 2:
            raise forms.ValidationError('사용자명을 2자 이상 입력해 주세요.')
        if len(v) > 20:
            raise forms.ValidationError('사용자명은 20자 이하로 입력해 주세요.')
        if not USERNAME_RE.fullmatch(v):
            raise forms.ValidationError(
                '사용자명은 한글, 영문, 숫자만 입력할 수 있습니다.'
            )
        return v

    # ── 아이디 (login id, username 에 저장) ──
    def clean_username(self):
        v = _strip_or_blank(self.cleaned_data.get('username'))
        if not v:
            raise forms.ValidationError('아이디를 입력해 주세요.')
        if ' ' in v:
            raise forms.ValidationError('아이디에는 공백을 입력할 수 없습니다.')
        if len(v) < 4:
            raise forms.ValidationError('아이디를 4자 이상 입력해 주세요.')
        if len(v) > 20:
            raise forms.ValidationError('아이디는 20자 이하로 입력해 주세요.')
        if not LOGIN_ID_RE.fullmatch(v):
            raise forms.ValidationError(
                '아이디는 영문 또는 숫자만 입력할 수 있습니다.'
            )
        if User.objects.filter(username=v).exists():
            raise forms.ValidationError('이미 사용 중인 아이디입니다.')
        return v

    # ── 비밀번호 ──
    def clean_password(self):
        v = self.cleaned_data.get('password') or ''
        if not v:
            raise forms.ValidationError('비밀번호를 입력해 주세요.')
        if ' ' in v:
            raise forms.ValidationError('비밀번호에는 공백을 입력할 수 없습니다.')
        if len(v) < 8:
            raise forms.ValidationError('비밀번호는 8자 이상 입력해 주세요.')
        if len(v) > 20:
            raise forms.ValidationError('비밀번호는 20자 이하로 입력해 주세요.')

        # 영문 / 숫자 / 특수문자 중 2가지 이상
        kinds = 0
        if re.search(r'[A-Za-z]', v): kinds += 1
        if re.search(r'\d',         v): kinds += 1
        if re.search(r'[^A-Za-z0-9]', v): kinds += 1
        if kinds < 2:
            raise forms.ValidationError(
                '비밀번호는 영문, 숫자, 특수문자 중 2가지 이상을 포함해 주세요.'
            )
        return v

    # ── 비밀번호 확인 ──
    def clean(self):
        cleaned = super().clean()
        pw  = cleaned.get('password')
        pw2 = cleaned.get('password_check')

        # password 자체가 invalid 인 경우는 이미 errors 에 들어가있어 스킵
        if pw is not None and not self.errors.get('password'):
            if not pw2:
                self.add_error('password_check', '비밀번호 확인을 입력해 주세요.')
            elif pw != pw2:
                self.add_error('password_check', '비밀번호가 일치하지 않습니다.')
        return cleaned

    # ── 소속 ──
    def clean_organization(self):
        v = self.cleaned_data.get('organization')
        if not v:
            raise forms.ValidationError('소속을 선택해 주세요.')
        try:
            org = Organization.objects.get(pk=v)
        except Organization.DoesNotExist:
            raise forms.ValidationError('유효하지 않은 소속입니다.')
        return org

    # ── 권한 (role) ──
    def clean_role(self):
        v = _strip_or_blank(self.cleaned_data.get('role'))
        valid = {choice[0] for choice in User.ROLE_CHOICES}
        if not v:
            raise forms.ValidationError('권한을 선택해 주세요.')
        if v not in valid:
            raise forms.ValidationError('유효하지 않은 권한입니다.')
        return v

    # ── 직위 (선택) ──
    def clean_position_obj(self):
        v = self.cleaned_data.get('position_obj')
        if not v:
            return None
        try:
            return Position.objects.get(pk=v, is_active=True)
        except Position.DoesNotExist:
            raise forms.ValidationError('유효하지 않은 직위입니다.')

    # ── 계정 상태 ──
    def clean_account_status(self):
        v = _strip_or_blank(self.cleaned_data.get('account_status'))
        if not v:
            raise forms.ValidationError('계정 상태를 선택해 주세요.')
        # 등록 시점엔 '잠금' 은 만들지 않음 — '사용' or '비활성' 만 허용
        if v not in (User.ACCOUNT_STATUS_ACTIVE, User.ACCOUNT_STATUS_DISABLED):
            raise forms.ValidationError('계정 상태를 선택해 주세요.')
        return v

    # ── 이메일 ──
    def clean_email(self):
        v = _strip_or_blank(self.cleaned_data.get('email'))
        if not v:
            return ''
        if len(v) > 100:
            raise forms.ValidationError('이메일은 100자 이하로 입력해 주세요.')
        try:
            EmailValidator(message='이메일 형식이 올바르지 않습니다.')(v)
        except forms.ValidationError:
            raise forms.ValidationError('이메일 형식이 올바르지 않습니다.')
        return v

    # ── 연락처 ──
    def clean_phone(self):
        v = _strip_or_blank(self.cleaned_data.get('phone'))
        if not v:
            return ''
        # 숫자/하이픈만 허용
        if not re.fullmatch(r'[\d\-]+', v):
            raise forms.ValidationError('연락처는 숫자만 입력할 수 있습니다.')
        if not PHONE_RE.fullmatch(v):
            raise forms.ValidationError('연락처 형식이 올바르지 않습니다.')
        return v

    # ── DB 반영 ──
    def save(self, *, created_by=None) -> User:
        d = self.cleaned_data
        u = User(
            username    = d['username'],
            first_name  = d['name'],
            email       = d.get('email') or '',
            phone       = d.get('phone') or '',
            role        = d['role'],
            organization= d['organization'],
            department  = d['organization'].name,   # legacy 동기화
            position_obj= d.get('position_obj'),
            position    = d['position_obj'].name if d.get('position_obj') else '',
            is_active   = (d['account_status'] == User.ACCOUNT_STATUS_ACTIVE),
            is_locked   = False,
        )
        u.set_password(d['password'])
        u.save()
        return u


# ═══════════════════════════════════════════════════════════
# 사용자 수정 폼 (아이디/비밀번호 제외 모두 변경 가능)
# ═══════════════════════════════════════════════════════════

class UserUpdateForm(forms.Form):
    """피그마 '사용자 정보 수정' 모달.
    아이디는 read-only, 비밀번호는 별도 '비밀번호 초기화' 버튼.
    """
    name           = forms.CharField(required=False)
    organization   = forms.IntegerField(required=False)
    role           = forms.CharField(required=False)
    position_obj   = forms.IntegerField(required=False)
    account_status = forms.CharField(required=False)
    email          = forms.CharField(required=False)
    phone          = forms.CharField(required=False)

    def __init__(self, *args, instance: User, **kwargs):
        super().__init__(*args, **kwargs)
        self.instance = instance

    # 사용자명 / 소속 / 권한 / 직위 / 이메일 / 연락처 :
    # 등록 폼과 동일한 validation 재사용
    clean_name         = UserCreateForm.clean_name
    clean_organization = UserCreateForm.clean_organization
    clean_role         = UserCreateForm.clean_role
    clean_position_obj = UserCreateForm.clean_position_obj
    clean_email        = UserCreateForm.clean_email
    clean_phone        = UserCreateForm.clean_phone

    def clean_account_status(self):
        v = _strip_or_blank(self.cleaned_data.get('account_status'))
        valid = (
            User.ACCOUNT_STATUS_ACTIVE,
            User.ACCOUNT_STATUS_LOCKED,
            User.ACCOUNT_STATUS_DISABLED,
        )
        if not v:
            raise forms.ValidationError('계정 상태를 선택해 주세요.')
        if v not in valid:
            raise forms.ValidationError('계정 상태를 선택해 주세요.')
        return v

    def save(self) -> User:
        d = self.cleaned_data
        u = self.instance
        u.first_name  = d['name']
        u.email       = d.get('email') or ''
        u.phone       = d.get('phone') or ''
        u.role        = d['role']
        u.organization= d['organization']
        u.department  = d['organization'].name
        u.position_obj= d.get('position_obj')
        u.position    = d['position_obj'].name if d.get('position_obj') else ''

        status = d['account_status']
        u.is_active = (status != User.ACCOUNT_STATUS_DISABLED)
        u.is_locked = (status == User.ACCOUNT_STATUS_LOCKED)

        u.save()
        return u


# ═══════════════════════════════════════════════════════════
# 조직 등록/수정 폼
# ═══════════════════════════════════════════════════════════

class OrganizationForm(forms.Form):
    name        = forms.CharField(required=False)
    code        = forms.CharField(required=False)
    parent      = forms.IntegerField(required=False)
    description = forms.CharField(required=False)

    def __init__(self, *args, instance: Organization | None = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.instance = instance  # 수정 시 None 이 아님

    def clean_name(self):
        v = _strip_or_blank(self.cleaned_data.get('name'))
        if not v:
            raise forms.ValidationError('부서명을 입력해 주세요.')
        if len(v) > 50:
            raise forms.ValidationError('부서명은 50자 이하로 입력해 주세요.')
        return v

    def clean_parent(self):
        v = self.cleaned_data.get('parent')
        if not v:
            return None  # 회사(root) 등록 가능
        try:
            return Organization.objects.get(pk=v)
        except Organization.DoesNotExist:
            raise forms.ValidationError('상위 조직이 유효하지 않습니다.')

    def clean(self):
        cleaned = super().clean()
        name   = cleaned.get('name')
        parent = cleaned.get('parent')
        if name:
            qs = Organization.objects.filter(parent=parent, name=name)
            if self.instance and self.instance.pk:
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                self.add_error('name', '같은 위치에 동일 부서명이 이미 존재합니다.')
        return cleaned

    def save(self, *, by=None) -> Organization:
        d = self.cleaned_data
        if self.instance and self.instance.pk:
            org = self.instance
        else:
            org = Organization(created_by=by)
        org.name   = d['name']
        org.code   = d.get('code') or ''
        org.parent = d.get('parent')
        org.description = d.get('description') or ''
        org.updated_by = by
        org.save()
        return org


# ═══════════════════════════════════════════════════════════
# 직위 등록/수정 폼
# ═══════════════════════════════════════════════════════════

class PositionForm(forms.Form):
    name       = forms.CharField(required=False)
    sort_order = forms.IntegerField(required=False, min_value=1, max_value=999)
    is_active  = forms.BooleanField(required=False)

    def __init__(self, *args, instance: Position | None = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.instance = instance

    def clean_name(self):
        v = _strip_or_blank(self.cleaned_data.get('name'))
        if not v:
            raise forms.ValidationError('직위명을 입력해 주세요.')
        if len(v) > 50:
            raise forms.ValidationError('직위명은 50자 이하로 입력해 주세요.')
        qs = Position.objects.filter(name=v)
        if self.instance and self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise forms.ValidationError('이미 등록된 직위명입니다.')
        return v

    def clean_sort_order(self):
        v = self.cleaned_data.get('sort_order')
        return v if v else 100

    def save(self, *, by=None) -> Position:
        d = self.cleaned_data
        if self.instance and self.instance.pk:
            p = self.instance
        else:
            p = Position(created_by=by)
        p.name       = d['name']
        p.sort_order = d['sort_order']
        p.is_active  = bool(d.get('is_active'))
        p.updated_by = by
        p.save()
        return p
