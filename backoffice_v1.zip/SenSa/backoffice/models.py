"""
backoffice/models.py — 백오피스 마스터 모델

- Organization : 회사 / 부서 트리 (피그마 '조직 관리')
- Position     : 직위 (피그마 '직위 관리')

설계 원칙:
  - 조직은 self-FK 트리 구조. 회사가 root, 부서가 leaf.
  - "조직 없음" 가상 부서는 is_unassigned_bucket=True 로 1건 시드 (부서 미지정 사용자가 자동 들어감).
  - 직위는 단순 마스터 (정렬 순서 + 사용 여부).
  - 두 모델 모두 백오피스 액션 추적용 (created_by, updated_by) 필드 포함.

[관계]
  accounts.User.organization  → Organization (FK, nullable)
  accounts.User.position_obj  → Position (FK, nullable)
"""
from django.conf import settings
from django.db import models


# ═══════════════════════════════════════════════════════════
# 조직 (회사 + 부서)
# ═══════════════════════════════════════════════════════════

class Organization(models.Model):
    """
    조직 노드 — 회사 또는 부서.

    parent=None 인 노드가 회사(root). 그 외는 부서.
    소규모 시스템 가정으로 깊이 제한은 두지 않으나,
    UI(조직 트리)는 2-depth (회사 > 부서) 까지만 지원.

    name 은 unique 가 아님 — 같은 회사 안의 부서끼리만 unique 권장(unique_together).
    """
    name = models.CharField(
        max_length=100,
        verbose_name='조직명',
        help_text='회사명 또는 부서명',
    )
    code = models.CharField(
        max_length=50,
        blank=True,
        default='',
        verbose_name='부서 코드',
        help_text='001, 002 ... 같은 식별 코드 (피그마 디자인)',
    )
    parent = models.ForeignKey(
        'self',
        on_delete=models.CASCADE,
        null=True, blank=True,
        related_name='children',
        verbose_name='상위 조직',
        help_text='None 이면 회사(root)',
    )
    description = models.TextField(
        blank=True,
        default='',
        verbose_name='설명',
    )
    leader = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='leading_organizations',
        verbose_name='조직장',
        help_text='해당 부서의 조직장 (구성원 중 1명)',
    )
    is_unassigned_bucket = models.BooleanField(
        default=False,
        verbose_name='조직 없음 버킷 여부',
        help_text='True 인 단일 노드가 부서 미지정 사용자의 자동 소속처',
    )
    sort_order = models.IntegerField(
        default=100,
        verbose_name='정렬 순서',
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='created_organizations',
    )
    updated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='updated_organizations',
    )

    class Meta:
        ordering = ['sort_order', 'name']
        verbose_name = '조직'
        verbose_name_plural = '조직 목록'
        # 같은 부모 아래 같은 이름 금지 (회사 트리 안에서 부서명 중복 방지)
        constraints = [
            models.UniqueConstraint(
                fields=['parent', 'name'],
                name='org_unique_name_per_parent',
            ),
        ]

    def __str__(self):
        return self.name

    @property
    def is_root(self) -> bool:
        return self.parent_id is None

    @property
    def member_count(self) -> int:
        """현재 소속 사용자 수"""
        return self.users.count()


# ═══════════════════════════════════════════════════════════
# 직위
# ═══════════════════════════════════════════════════════════

class Position(models.Model):
    """
    직위 마스터.

    피그마 디자인: 대표이사 / 이사 / 부장 / 차장 / 과장 / 대리 / 사원 등
    sort_order 1=최상위 (대표이사), 큰 숫자일수록 하위 직위.
    """
    name = models.CharField(
        max_length=50,
        unique=True,
        verbose_name='직위명',
    )
    sort_order = models.IntegerField(
        default=100,
        verbose_name='정렬 순서',
        help_text='작을수록 상위 직위 (대표이사=1)',
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name='사용 여부',
        help_text='False 면 신규 사용자 등록 시 선택 목록에서 제외',
    )
    description = models.TextField(
        blank=True,
        default='',
        verbose_name='설명',
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='created_positions',
    )
    updated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='updated_positions',
    )

    class Meta:
        ordering = ['sort_order', 'name']
        verbose_name = '직위'
        verbose_name_plural = '직위 목록'

    def __str__(self):
        return self.name
