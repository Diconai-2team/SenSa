"""
backoffice/urls.py — /backoffice/ 하위 라우팅.

규칙:
  - 페이지: 깔끔한 URL ('users/', 'organizations/', 'positions/')
  - JSON API: 'api/' 프리픽스 (CSRF 는 세션 인증으로 자동 적용)
"""
from django.urls import path

from . import views


app_name = 'backoffice'

urlpatterns = [
    # ═══════════════════════════════════════════════════════
    # 페이지
    # ═══════════════════════════════════════════════════════
    path('', views.landing, name='landing'),

    path('users/',          views.user_list,           name='user-list'),
    path('organizations/',  views.organization_manage, name='org-manage'),
    path('positions/',      views.position_list,       name='position-list'),

    # ═══════════════════════════════════════════════════════
    # 사용자 관리 API
    # ═══════════════════════════════════════════════════════
    path('api/users/<int:pk>/',        views.user_detail_api, name='api-user-detail'),
    path('api/users/create/',          views.user_create_api, name='api-user-create'),
    path('api/users/<int:pk>/update/', views.user_update_api, name='api-user-update'),
    path('api/users/bulk-delete/',     views.user_bulk_delete_api, name='api-user-bulk-delete'),
    path('api/users/bulk-lock/',       views.user_bulk_lock_api,   name='api-user-bulk-lock'),
    path('api/users/bulk-unlock/',     views.user_bulk_unlock_api, name='api-user-bulk-unlock'),

    # ═══════════════════════════════════════════════════════
    # 조직 관리 API
    # ═══════════════════════════════════════════════════════
    path('api/organizations/<int:pk>/',         views.organization_detail_api,         name='api-org-detail'),
    path('api/organizations/create/',           views.organization_create_api,         name='api-org-create'),
    path('api/organizations/<int:pk>/update/',  views.organization_update_api,         name='api-org-update'),
    path('api/organizations/<int:pk>/delete/',  views.organization_delete_api,         name='api-org-delete'),
    path('api/organizations/<int:pk>/assign/',  views.organization_assign_members_api, name='api-org-assign'),
    path('api/organizations/<int:pk>/remove/',  views.organization_remove_members_api, name='api-org-remove'),
    path('api/organizations/<int:pk>/set-leader/', views.organization_set_leader_api, name='api-org-set-leader'),
    path('api/organizations/member-picker/',    views.organization_member_picker_api,  name='api-org-member-picker'),

    # ═══════════════════════════════════════════════════════
    # 직위 관리 API
    # ═══════════════════════════════════════════════════════
    path('api/positions/<int:pk>/',        views.position_detail_api, name='api-position-detail'),
    path('api/positions/create/',          views.position_create_api, name='api-position-create'),
    path('api/positions/<int:pk>/update/', views.position_update_api, name='api-position-update'),
    path('api/positions/bulk-delete/',     views.position_bulk_delete_api, name='api-position-bulk-delete'),
]
