from django.apps import AppConfig


class BackofficeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'backoffice'
    verbose_name = '백오피스 (관리자 콘솔)'

    def ready(self):
        # 시그널 등록 — alerts.Alarm 생성 시 알림 디스패처 자동 트리거
        # noqa: F401 — import 자체가 시그널 등록의 부작용
        from . import signals  # noqa: F401
