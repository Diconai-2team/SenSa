"""
backoffice/signals.py — 알람 → 알림 발송 자동 트리거.

apps.py 의 ready() 에서 import 하여 활성화됨.
"""
import logging

from django.db.models.signals import post_save
from django.dispatch import receiver

from alerts.models import Alarm

from .notification_dispatcher import dispatch_for_alarm


logger = logging.getLogger(__name__)


@receiver(post_save, sender=Alarm)
def alarm_post_save_handler(sender, instance, created, **kwargs):
    """알람이 새로 생성되면 매칭 정책에 따라 NotificationLog 작성."""
    if not created:
        return  # 업데이트(예: is_read 변경) 는 무시
    try:
        n = dispatch_for_alarm(instance)
        if n > 0:
            logger.info('[backoffice.signals] alarm=%s → %d notifications dispatched', instance.id, n)
    except Exception as e:
        # 알림 발송 실패가 알람 생성을 막아선 안 됨
        logger.exception('[backoffice.signals] alarm dispatch error: %r', e)
