"""
backoffice/models.py — 백오피스 마스터 모델

- Organization : 회사 / 부서 트리 (피그마 '조직 관리')
- Position     : 직위 (피그마 '직위 관리')

설계 원칙:
  - 조직은 self-FK 트리 구조. 회사가 root, 부서가 leaf.
  - "조직 없음" 가상 부서는 is_unassigned_bucket=True 로 1건 시드 (부서 미지정 사용자가 자동 들어감).
  - 직위는 단순 마스터 (정렬 순서 + 사용 여부).
  - 두 모델 모두 백오피스 액션 추적용 (created_by, updated_by) 필드 포함.

[관계]
  accounts.User.organization  → Organization (FK, nullable)
  accounts.User.position_obj  → Position (FK, nullable)
"""
from django.conf import settings
from django.db import models


# ═══════════════════════════════════════════════════════════
# 조직 (회사 + 부서)
# ═══════════════════════════════════════════════════════════

class Organization(models.Model):
    """
    조직 노드 — 회사 또는 부서.

    parent=None 인 노드가 회사(root). 그 외는 부서.
    소규모 시스템 가정으로 깊이 제한은 두지 않으나,
    UI(조직 트리)는 2-depth (회사 > 부서) 까지만 지원.

    name 은 unique 가 아님 — 같은 회사 안의 부서끼리만 unique 권장(unique_together).
    """
    name = models.CharField(
        max_length=100,
        verbose_name='조직명',
        help_text='회사명 또는 부서명',
    )
    code = models.CharField(
        max_length=50,
        blank=True,
        default='',
        verbose_name='부서 코드',
        help_text='001, 002 ... 같은 식별 코드 (피그마 디자인)',
    )
    parent = models.ForeignKey(
        'self',
        on_delete=models.CASCADE,
        null=True, blank=True,
        related_name='children',
        verbose_name='상위 조직',
        help_text='None 이면 회사(root)',
    )
    description = models.TextField(
        blank=True,
        default='',
        verbose_name='설명',
    )
    leader = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='leading_organizations',
        verbose_name='조직장',
        help_text='해당 부서의 조직장 (구성원 중 1명)',
    )
    is_unassigned_bucket = models.BooleanField(
        default=False,
        verbose_name='조직 없음 버킷 여부',
        help_text='True 인 단일 노드가 부서 미지정 사용자의 자동 소속처',
    )
    sort_order = models.IntegerField(
        default=100,
        verbose_name='정렬 순서',
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='created_organizations',
    )
    updated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='updated_organizations',
    )

    class Meta:
        ordering = ['sort_order', 'name']
        verbose_name = '조직'
        verbose_name_plural = '조직 목록'
        # 같은 부모 아래 같은 이름 금지 (회사 트리 안에서 부서명 중복 방지)
        constraints = [
            models.UniqueConstraint(
                fields=['parent', 'name'],
                name='org_unique_name_per_parent',
            ),
        ]

    def __str__(self):
        return self.name

    @property
    def is_root(self) -> bool:
        return self.parent_id is None

    @property
    def member_count(self) -> int:
        """현재 소속 사용자 수"""
        return self.users.count()


# ═══════════════════════════════════════════════════════════
# 직위
# ═══════════════════════════════════════════════════════════

class Position(models.Model):
    """
    직위 마스터.

    피그마 디자인: 대표이사 / 이사 / 부장 / 차장 / 과장 / 대리 / 사원 등
    sort_order 1=최상위 (대표이사), 큰 숫자일수록 하위 직위.
    """
    name = models.CharField(
        max_length=50,
        unique=True,
        verbose_name='직위명',
    )
    sort_order = models.IntegerField(
        default=100,
        verbose_name='정렬 순서',
        help_text='작을수록 상위 직위 (대표이사=1)',
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name='사용 여부',
        help_text='False 면 신규 사용자 등록 시 선택 목록에서 제외',
    )
    description = models.TextField(
        blank=True,
        default='',
        verbose_name='설명',
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='created_positions',
    )
    updated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='updated_positions',
    )

    class Meta:
        ordering = ['sort_order', 'name']
        verbose_name = '직위'
        verbose_name_plural = '직위 목록'

    def __str__(self):
        return self.name


# ═══════════════════════════════════════════════════════════
# 공통 코드 (CodeGroup + Code) — 피그마 '공통 코드 관리'
# ═══════════════════════════════════════════════════════════
#
# 2-level 마스터:
#   - CodeGroup: DEVICE_TYPE / GAS_TYPE / UNIT_CODE / EVENT_TYPE / NOTIF_CHANNEL ...
#   - Code     : 그룹 안의 개별 코드 (예: GAS_TYPE 그룹 안의 CO/H2S/CH4 ...)
#
# 다른 도메인(임계치/위험유형/장비)이 단위·종류 등을 참조할 때 활용.

class CodeGroup(models.Model):
    code = models.CharField(
        max_length=50, unique=True,
        verbose_name='코드 그룹', help_text='UPPER_SNAKE_CASE (예: DEVICE_TYPE)',
    )
    name = models.CharField(max_length=50, verbose_name='그룹명')
    description = models.TextField(blank=True, default='', verbose_name='설명')
    sort_order = models.IntegerField(default=100, verbose_name='정렬 순서')
    is_active = models.BooleanField(default=True, verbose_name='사용 여부')
    is_system = models.BooleanField(
        default=False, verbose_name='시스템 그룹 여부',
        help_text='True 면 그룹 자체 삭제 불가 (시드된 핵심 그룹 보호)',
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='created_codegroups')
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='updated_codegroups')

    class Meta:
        ordering = ['sort_order', 'code']
        verbose_name = '코드 그룹'
        verbose_name_plural = '코드 그룹 목록'

    def __str__(self):
        return f'{self.name} ({self.code})'

    @property
    def code_count(self):
        return self.codes.count()


class Code(models.Model):
    group = models.ForeignKey(CodeGroup, on_delete=models.CASCADE, related_name='codes', verbose_name='코드 그룹')
    code = models.CharField(max_length=50, verbose_name='코드')
    name = models.CharField(max_length=100, verbose_name='코드명')
    description = models.TextField(blank=True, default='', verbose_name='설명')
    sort_order = models.IntegerField(default=100, verbose_name='정렬 순서')
    is_active = models.BooleanField(default=True, verbose_name='사용 여부')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='created_codes')
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='updated_codes')

    class Meta:
        ordering = ['sort_order', 'code']
        verbose_name = '코드'
        verbose_name_plural = '코드 목록'
        constraints = [
            models.UniqueConstraint(fields=['group', 'code'], name='code_unique_per_group'),
        ]

    def __str__(self):
        return f'{self.group.code}.{self.code}'


# ═══════════════════════════════════════════════════════════
# 위험 유형 (RiskCategory + RiskType) — 피그마 '위험 유형 관리'
# ═══════════════════════════════════════════════════════════
#
# 2-level 마스터:
#   - RiskCategory: RISK_GAS / RISK_POWER / RISK_LOCATION / RISK_WORK ...
#   - RiskType    : 카테고리 안의 개별 유형 (예: GAS_LEAK, POWER_OVERLOAD)
#
# 반영 위치 (applies_to): 실시간 관제 / 이벤트 이력 / 알림 - multi-check.

# applies_to 는 사용 패턴이 많아 별도 테이블 대신 CSV 문자열로 저장 (단순화).
# 화면에서는 'realtime,event,alarm' → ['실시간 관제','이벤트 이력','알림'] 변환.
APPLIES_TO_CHOICES_RISK = [
    ('realtime', '실시간 관제'),
    ('event',    '이벤트 이력'),
    ('alarm',    '알림'),
]

class RiskCategory(models.Model):
    code = models.CharField(max_length=50, unique=True, verbose_name='분류 코드')
    name = models.CharField(max_length=50, verbose_name='분류명')
    description = models.TextField(blank=True, default='', verbose_name='설명')
    applies_to = models.CharField(
        max_length=100, blank=True, default='',
        verbose_name='반영 범위',
        help_text='CSV: realtime,event,alarm',
    )
    sort_order = models.IntegerField(default=100, verbose_name='정렬 순서')
    is_active = models.BooleanField(default=True, verbose_name='사용 여부')
    is_system = models.BooleanField(default=False, verbose_name='시스템 분류 여부')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='created_risk_categories')
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='updated_risk_categories')

    class Meta:
        ordering = ['sort_order', 'code']
        verbose_name = '위험 분류'
        verbose_name_plural = '위험 분류 목록'

    def __str__(self):
        return f'{self.name} ({self.code})'

    @property
    def applies_to_list(self):
        return [s for s in (self.applies_to or '').split(',') if s]

    @property
    def type_count(self):
        return self.types.count()


class RiskType(models.Model):
    category = models.ForeignKey(RiskCategory, on_delete=models.CASCADE, related_name='types', verbose_name='위험 분류')
    code = models.CharField(max_length=50, verbose_name='유형 코드')
    name = models.CharField(max_length=100, verbose_name='유형명')
    description = models.TextField(blank=True, default='', verbose_name='설명')
    show_on_map = models.BooleanField(default=True, verbose_name='지도 반영 여부')
    sort_order = models.IntegerField(default=100, verbose_name='정렬 순서')
    is_active = models.BooleanField(default=True, verbose_name='사용 여부')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='created_risk_types')
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='updated_risk_types')

    class Meta:
        ordering = ['sort_order', 'code']
        verbose_name = '위험 유형'
        verbose_name_plural = '위험 유형 목록'
        constraints = [
            models.UniqueConstraint(fields=['category', 'code'], name='risk_type_unique_per_category'),
        ]

    def __str__(self):
        return f'{self.category.code}.{self.code}'


# ═══════════════════════════════════════════════════════════
# 위험 기준 (AlarmLevel) — 피그마 '위험 기준 관리'
# ═══════════════════════════════════════════════════════════
#
# 단일 레벨 마스터. 알림 단계 (정상/주의/경고/위험 ...) 정의.
# alerts.Alarm 의 level CharField 와 향후 연동.

ALARM_COLOR_CHOICES = [
    ('gray',   '회색'),
    ('green',  '녹색'),
    ('yellow', '황색'),
    ('orange', '주황색'),
    ('red',    '적색'),
    ('black',  '검정색'),
]

ALARM_INTENSITY_CHOICES = [
    ('normal',  '정상'),
    ('caution', '주의'),
    ('warning', '경고'),
    ('danger',  '위험'),
]

class AlarmLevel(models.Model):
    code = models.CharField(
        max_length=50, unique=True,
        verbose_name='단계 코드',
        help_text='UPPER 영문/숫자/언더스코어 (예: WARNING)',
    )
    name = models.CharField(max_length=20, verbose_name='단계명')
    color = models.CharField(max_length=20, choices=ALARM_COLOR_CHOICES, verbose_name='표시 색상')
    intensity = models.CharField(max_length=20, choices=ALARM_INTENSITY_CHOICES, verbose_name='알림 강도')
    priority = models.IntegerField(
        default=100, verbose_name='이벤트 우선순위',
        help_text='작을수록 높은 우선순위 (정상=10, 위험=90 같은 식)',
    )
    description = models.TextField(blank=True, default='', verbose_name='설명')
    is_active = models.BooleanField(default=True, verbose_name='사용 여부')
    is_system = models.BooleanField(default=False, verbose_name='시스템 단계 여부')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='created_alarm_levels')
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='updated_alarm_levels')

    class Meta:
        ordering = ['priority', 'code']
        verbose_name = '위험 기준'
        verbose_name_plural = '위험 기준 목록'

    def __str__(self):
        return f'{self.name} ({self.code})'


# ═══════════════════════════════════════════════════════════
# 임계치 기준 (ThresholdCategory + Threshold) — 피그마 '임계치 기준 관리'
# ═══════════════════════════════════════════════════════════
#
# **이 모델이 실제로 시스템 동작을 바꾼다.**
# FastAPI generators.py 의 GAS_THRESHOLDS 하드코딩을 대체.
#
# 2-level:
#   - ThresholdCategory: TH_GAS / TH_POWER / TH_AI / TH_COMMON
#   - Threshold       : 카테고리 안의 측정 항목별 임계치
#
# 판단 조건 (operator):
#   - 'over'  → caution_value 초과 시 주의, danger_value 초과 시 위험
#   - 'under' → caution_value 미만 시 주의, danger_value 미만 시 위험 (산소 등)
#
# 반영 범위 (applies_to): realtime / ai_predict / alarm — CSV.

THRESHOLD_OPERATOR_CHOICES = [
    ('over',  '초과'),
    ('under', '이하'),
]

APPLIES_TO_CHOICES_THRESHOLD = [
    ('realtime',   '실시간 관제'),
    ('ai_predict', 'AI 예측'),
    ('alarm',      '알림'),
]

class ThresholdCategory(models.Model):
    code = models.CharField(max_length=50, unique=True, verbose_name='분류 코드')
    name = models.CharField(max_length=50, verbose_name='분류명')
    description = models.TextField(blank=True, default='', verbose_name='설명')
    applies_to = models.CharField(
        max_length=100, blank=True, default='',
        verbose_name='반영 범위',
        help_text='CSV: realtime,ai_predict,alarm',
    )
    sort_order = models.IntegerField(default=100, verbose_name='정렬 순서')
    is_active = models.BooleanField(default=True, verbose_name='사용 여부')
    is_system = models.BooleanField(default=False, verbose_name='시스템 분류 여부')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='created_threshold_categories')
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='updated_threshold_categories')

    class Meta:
        ordering = ['sort_order', 'code']
        verbose_name = '임계치 분류'
        verbose_name_plural = '임계치 분류 목록'

    def __str__(self):
        return f'{self.name} ({self.code})'

    @property
    def applies_to_list(self):
        return [s for s in (self.applies_to or '').split(',') if s]

    @property
    def threshold_count(self):
        return self.thresholds.count()


class Threshold(models.Model):
    category = models.ForeignKey(ThresholdCategory, on_delete=models.CASCADE, related_name='thresholds', verbose_name='임계치 분류')
    item_code = models.CharField(
        max_length=50, verbose_name='측정 항목 코드',
        help_text='가스: co/h2s/co2/o2/no2/so2/o3/nh3/voc/ch4 — generators.py 키와 일치',
    )
    item_name = models.CharField(max_length=50, verbose_name='측정 항목명')
    unit = models.CharField(max_length=20, verbose_name='단위', help_text='ppm / %LEL / % / A / V')
    operator = models.CharField(
        max_length=10, choices=THRESHOLD_OPERATOR_CHOICES, default='over',
        verbose_name='판단 조건',
    )
    caution_value = models.FloatField(verbose_name='주의값')
    danger_value = models.FloatField(verbose_name='위험값')
    is_active = models.BooleanField(default=True, verbose_name='사용 여부')
    applies_to = models.CharField(
        max_length=100, blank=True, default='realtime,alarm',
        verbose_name='반영 범위',
        help_text='CSV: realtime,ai_predict,alarm',
    )
    description = models.TextField(blank=True, default='', verbose_name='설명')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='created_thresholds')
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='updated_thresholds')

    class Meta:
        ordering = ['category__sort_order', 'item_code']
        verbose_name = '임계치 기준'
        verbose_name_plural = '임계치 기준 목록'
        constraints = [
            models.UniqueConstraint(fields=['category', 'item_code'], name='threshold_unique_per_category'),
        ]

    def __str__(self):
        return f'{self.category.code}.{self.item_code} ({self.caution_value}/{self.danger_value})'

    @property
    def applies_to_list(self):
        return [s for s in (self.applies_to or '').split(',') if s]
