"""
backoffice/urls.py — /backoffice/ 하위 라우팅.

규칙:
  - 페이지: 깔끔한 URL ('users/', 'organizations/', 'positions/')
  - JSON API: 'api/' 프리픽스 (CSRF 는 세션 인증으로 자동 적용)
"""
from django.urls import path

from . import views


app_name = 'backoffice'

urlpatterns = [
    # ═══════════════════════════════════════════════════════
    # 페이지
    # ═══════════════════════════════════════════════════════
    path('', views.landing, name='landing'),

    path('users/',          views.user_list,           name='user-list'),
    path('organizations/',  views.organization_manage, name='org-manage'),
    path('positions/',      views.position_list,       name='position-list'),

    # ═══════════════════════════════════════════════════════
    # 사용자 관리 API
    # ═══════════════════════════════════════════════════════
    path('api/users/<int:pk>/',        views.user_detail_api, name='api-user-detail'),
    path('api/users/create/',          views.user_create_api, name='api-user-create'),
    path('api/users/<int:pk>/update/', views.user_update_api, name='api-user-update'),
    path('api/users/bulk-delete/',     views.user_bulk_delete_api, name='api-user-bulk-delete'),
    path('api/users/bulk-lock/',       views.user_bulk_lock_api,   name='api-user-bulk-lock'),
    path('api/users/bulk-unlock/',     views.user_bulk_unlock_api, name='api-user-bulk-unlock'),

    # ═══════════════════════════════════════════════════════
    # 조직 관리 API
    # ═══════════════════════════════════════════════════════
    path('api/organizations/<int:pk>/',         views.organization_detail_api,         name='api-org-detail'),
    path('api/organizations/create/',           views.organization_create_api,         name='api-org-create'),
    path('api/organizations/<int:pk>/update/',  views.organization_update_api,         name='api-org-update'),
    path('api/organizations/<int:pk>/delete/',  views.organization_delete_api,         name='api-org-delete'),
    path('api/organizations/<int:pk>/assign/',  views.organization_assign_members_api, name='api-org-assign'),
    path('api/organizations/<int:pk>/remove/',  views.organization_remove_members_api, name='api-org-remove'),
    path('api/organizations/<int:pk>/set-leader/', views.organization_set_leader_api, name='api-org-set-leader'),
    path('api/organizations/member-picker/',    views.organization_member_picker_api,  name='api-org-member-picker'),

    # ═══════════════════════════════════════════════════════
    # 직위 관리 API
    # ═══════════════════════════════════════════════════════
    path('api/positions/<int:pk>/',        views.position_detail_api, name='api-position-detail'),
    path('api/positions/create/',          views.position_create_api, name='api-position-create'),
    path('api/positions/<int:pk>/update/', views.position_update_api, name='api-position-update'),
    path('api/positions/bulk-delete/',     views.position_bulk_delete_api, name='api-position-bulk-delete'),

    # ═══════════════════════════════════════════════════════
    # 공통 코드 관리
    # ═══════════════════════════════════════════════════════
    path('codes/', views.code_manage, name='code-manage'),
    path('api/code-groups/<int:pk>/',          views.code_group_detail_api,  name='api-cg-detail'),
    path('api/code-groups/create/',            views.code_group_create_api,  name='api-cg-create'),
    path('api/code-groups/<int:pk>/update/',   views.code_group_update_api,  name='api-cg-update'),
    path('api/code-groups/<int:pk>/delete/',   views.code_group_delete_api,  name='api-cg-delete'),
    path('api/codes/create/',                  views.code_create_api,        name='api-code-create'),
    path('api/codes/<int:pk>/update/',         views.code_update_api,        name='api-code-update'),
    path('api/codes/bulk-delete/',             views.code_bulk_delete_api,   name='api-code-bulk-delete'),
    path('api/codes/bulk-toggle/',             views.code_bulk_toggle_api,   name='api-code-bulk-toggle'),

    # ═══════════════════════════════════════════════════════
    # 위험 유형 관리
    # ═══════════════════════════════════════════════════════
    path('risks/', views.risk_manage, name='risk-manage'),
    path('api/risk-categories/<int:pk>/',         views.risk_cat_detail_api,    name='api-risk-cat-detail'),
    path('api/risk-categories/create/',           views.risk_cat_create_api,    name='api-risk-cat-create'),
    path('api/risk-categories/<int:pk>/update/',  views.risk_cat_update_api,    name='api-risk-cat-update'),
    path('api/risk-categories/<int:pk>/delete/',  views.risk_cat_delete_api,    name='api-risk-cat-delete'),
    path('api/risk-types/create/',                views.risk_type_create_api,   name='api-risk-type-create'),
    path('api/risk-types/<int:pk>/update/',       views.risk_type_update_api,   name='api-risk-type-update'),
    path('api/risk-types/bulk-delete/',           views.risk_type_bulk_delete_api, name='api-risk-type-bulk-delete'),

    # ═══════════════════════════════════════════════════════
    # 위험 기준 (알람 단계) 관리
    # ═══════════════════════════════════════════════════════
    path('alarm-levels/', views.alarm_level_list, name='alarm-level-list'),
    path('api/alarm-levels/<int:pk>/',          views.alarm_level_detail_api,    name='api-al-detail'),
    path('api/alarm-levels/create/',            views.alarm_level_create_api,    name='api-al-create'),
    path('api/alarm-levels/<int:pk>/update/',   views.alarm_level_update_api,    name='api-al-update'),
    path('api/alarm-levels/bulk-delete/',       views.alarm_level_bulk_delete_api, name='api-al-bulk-delete'),

    # ═══════════════════════════════════════════════════════
    # 임계치 기준 관리
    # ═══════════════════════════════════════════════════════
    path('thresholds/', views.threshold_manage, name='threshold-manage'),
    path('api/threshold-categories/<int:pk>/',         views.threshold_cat_detail_api,  name='api-th-cat-detail'),
    path('api/threshold-categories/create/',           views.threshold_cat_create_api,  name='api-th-cat-create'),
    path('api/threshold-categories/<int:pk>/update/',  views.threshold_cat_update_api,  name='api-th-cat-update'),
    path('api/thresholds/create/',                     views.threshold_create_api,      name='api-th-create'),
    path('api/thresholds/<int:pk>/update/',            views.threshold_update_api,      name='api-th-update'),
    path('api/thresholds/bulk-delete/',                views.threshold_bulk_delete_api, name='api-th-bulk-delete'),
    path('api/thresholds/bulk-toggle/',                views.threshold_bulk_toggle_api, name='api-th-bulk-toggle'),
]
