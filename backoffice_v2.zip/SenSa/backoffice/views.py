"""
backoffice/views.py — 백오피스 (슈퍼관리자 채널) 뷰

구조:
  - landing                 : /backoffice/                 (대시보드)
  - users.*                 : /backoffice/users/...        (사용자 관리)
  - organizations.*         : /backoffice/organizations/   (조직 관리)
  - positions.*             : /backoffice/positions/       (직위 관리)

페이지는 함수 뷰 + Django Template,
액션 (등록/수정/삭제/잠금/잠금해제) 은 JSON API.

브라우저는 페이지 → AJAX(fetch) → JSON 으로 모달 처리.
"""
import json

from django.db.models import Q, Case, When, IntegerField, Value
from django.http import JsonResponse, Http404
from django.shortcuts import render, get_object_or_404
from django.urls import reverse
from django.views.decorators.http import require_GET, require_POST

from accounts.models import User

from .models import Organization, Position
from .forms import (
    UserCreateForm, UserUpdateForm,
    OrganizationForm, PositionForm,
)
from .permissions import super_admin_required, super_admin_required_api


# ═══════════════════════════════════════════════════════════
# 공통 — JSON 본문 파싱 + 폼 에러 직렬화
# ═══════════════════════════════════════════════════════════

def _parse_json(request) -> dict:
    """request.body 에서 JSON 디코드. 실패 시 빈 dict."""
    if not request.body:
        return {}
    try:
        return json.loads(request.body.decode('utf-8') or '{}')
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {}


def _form_errors_payload(form) -> dict:
    """form.errors → 프런트가 필드별로 표시하기 좋은 형태로 변환."""
    return {
        field: [str(err) for err in errs]
        for field, errs in form.errors.items()
    }


# ═══════════════════════════════════════════════════════════
# 랜딩 — /backoffice/
# ═══════════════════════════════════════════════════════════

@super_admin_required
def landing(request):
    """백오피스 메인 진입 화면.
    피그마는 진입 시 '사용자 관리' 가 첫 화면이지만,
    URL 분리를 위해 짧은 환영 페이지(통계 카드 + 메뉴 진입 안내) 로 둠.
    """
    ctx = {
        'stats': {
            'user_count'    : User.objects.count(),
            'org_count'     : Organization.objects.exclude(
                is_unassigned_bucket=True
            ).count(),
            'position_count': Position.objects.filter(is_active=True).count(),
            'locked_count'  : User.objects.filter(is_locked=True).count(),
        },
    }
    return render(request, 'backoffice/landing.html', ctx)


# ═══════════════════════════════════════════════════════════
# 사용자 관리 — 페이지
# ═══════════════════════════════════════════════════════════

USER_PAGE_SIZE = 10

USER_SORT_OPTIONS = {
    'name_asc'      : ('first_name', '사용자명 오름차순'),
    'last_login_desc': ('-last_login', '최근 로그인순'),
    'created_desc'  : ('-date_joined', '등록일순'),
    'role_asc'      : ('role', '권한순'),
    'status_asc'    : (None, '계정 상태순'),  # is_active+is_locked 합성, 아래에서 처리
}


@super_admin_required
def user_list(request):
    """사용자 관리 — 목록 페이지 + 검색/필터/정렬/페이지네이션 (서버 렌더)."""
    qs = User.objects.select_related('organization', 'position_obj').all()

    # ── 검색 필터 ──
    q_name   = request.GET.get('name', '').strip()
    q_org    = request.GET.get('organization', '').strip()
    q_pos    = request.GET.get('position', '').strip()
    q_role   = request.GET.get('role', '').strip()
    q_status = request.GET.get('status', '').strip()

    if q_name:
        qs = qs.filter(
            Q(first_name__icontains=q_name) |
            Q(username__icontains=q_name)
        )
    if q_org:
        qs = qs.filter(organization_id=q_org)
    if q_pos:
        qs = qs.filter(position_obj_id=q_pos)
    if q_role:
        qs = qs.filter(role=q_role)
    if q_status == 'active':
        qs = qs.filter(is_active=True, is_locked=False)
    elif q_status == 'locked':
        qs = qs.filter(is_active=True, is_locked=True)
    elif q_status == 'disabled':
        qs = qs.filter(is_active=False)

    # ── 정렬 ──
    sort = request.GET.get('sort', 'name_asc')
    if sort == 'status_asc':
        # 사용(0) < 잠금(1) < 비활성(2) 순으로 정렬되도록 합성 키
        qs = qs.annotate(
            _status_key=Case(
                When(is_active=False, then=Value(2)),
                When(is_active=True, is_locked=True, then=Value(1)),
                default=Value(0),
                output_field=IntegerField(),
            )
        ).order_by('_status_key', 'first_name')
    else:
        order_field = USER_SORT_OPTIONS.get(sort, USER_SORT_OPTIONS['name_asc'])[0]
        qs = qs.order_by(order_field, 'first_name')

    # ── 페이지네이션 ──
    total = qs.count()
    try:
        page = max(1, int(request.GET.get('page', 1)))
    except ValueError:
        page = 1
    start = (page - 1) * USER_PAGE_SIZE
    rows = list(qs[start:start + USER_PAGE_SIZE])
    last_page = max(1, (total + USER_PAGE_SIZE - 1) // USER_PAGE_SIZE)

    ctx = {
        'rows'         : rows,
        'total'        : total,
        'page'         : page,
        'last_page'    : last_page,
        'page_size'    : USER_PAGE_SIZE,
        'page_start'   : start + 1 if total else 0,
        'page_end'     : min(start + USER_PAGE_SIZE, total),
        'page_range'   : range(1, last_page + 1),
        'sort'         : sort,
        'sort_options' : [(k, v[1]) for k, v in USER_SORT_OPTIONS.items()],
        'organizations': Organization.objects.filter(parent__isnull=False).order_by('sort_order'),
        'positions'    : Position.objects.filter(is_active=True),
        'roles'        : User.ROLE_CHOICES,
        'q': {
            'name': q_name, 'organization': q_org, 'position': q_pos,
            'role': q_role, 'status': q_status,
        },
    }
    return render(request, 'backoffice/users/list.html', ctx)


# ═══════════════════════════════════════════════════════════
# 사용자 관리 — JSON API
# ═══════════════════════════════════════════════════════════

def _user_to_dict(u: User) -> dict:
    return {
        'id'             : u.id,
        'name'           : u.first_name,
        'username'       : u.username,
        'organization_id': u.organization_id,
        'organization'   : u.display_organization,
        'position_obj_id': u.position_obj_id,
        'position'       : u.display_position,
        'role'           : u.role,
        'role_display'   : u.get_role_display(),
        'account_status' : u.account_status,
        'account_status_display': u.account_status_display,
        'email'          : u.email,
        'phone'          : u.phone,
        'last_login'     : u.last_login.strftime('%Y-%m-%d %H:%M:%S') if u.last_login else '-',
        'date_joined'    : u.date_joined.strftime('%Y-%m-%d') if u.date_joined else '-',
    }


@super_admin_required_api
@require_GET
def user_detail_api(request, pk):
    u = get_object_or_404(
        User.objects.select_related('organization', 'position_obj'),
        pk=pk,
    )
    return JsonResponse({'user': _user_to_dict(u)})


@super_admin_required_api
@require_POST
def user_create_api(request):
    form = UserCreateForm(_parse_json(request))
    if not form.is_valid():
        return JsonResponse(
            {'ok': False, 'errors': _form_errors_payload(form)},
            status=400,
        )
    u = form.save(created_by=request.user)
    return JsonResponse({'ok': True, 'user': _user_to_dict(u)})


@super_admin_required_api
@require_POST
def user_update_api(request, pk):
    u = get_object_or_404(User, pk=pk)
    form = UserUpdateForm(_parse_json(request), instance=u)
    if not form.is_valid():
        return JsonResponse(
            {'ok': False, 'errors': _form_errors_payload(form)},
            status=400,
        )
    u = form.save()
    return JsonResponse({'ok': True, 'user': _user_to_dict(u)})


@super_admin_required_api
@require_POST
def user_bulk_delete_api(request):
    """선택된 사용자 일괄 삭제. body: {"ids": [1, 2, 3]}"""
    ids = _parse_json(request).get('ids') or []
    if not isinstance(ids, list) or not ids:
        return JsonResponse({'ok': False, 'error': '대상 없음'}, status=400)
    # 자기 자신 삭제 방지
    if request.user.id in ids:
        return JsonResponse(
            {'ok': False, 'error': '본인 계정은 삭제할 수 없습니다.'},
            status=400,
        )
    deleted, _ = User.objects.filter(id__in=ids).delete()
    return JsonResponse({'ok': True, 'deleted': deleted})


@super_admin_required_api
@require_POST
def user_bulk_lock_api(request):
    ids = _parse_json(request).get('ids') or []
    if not ids:
        return JsonResponse({'ok': False, 'error': '대상 없음'}, status=400)
    if request.user.id in ids:
        return JsonResponse(
            {'ok': False, 'error': '본인 계정은 잠글 수 없습니다.'},
            status=400,
        )
    n = User.objects.filter(id__in=ids, is_active=True).update(is_locked=True)
    return JsonResponse({'ok': True, 'locked': n})


@super_admin_required_api
@require_POST
def user_bulk_unlock_api(request):
    ids = _parse_json(request).get('ids') or []
    if not ids:
        return JsonResponse({'ok': False, 'error': '대상 없음'}, status=400)
    n = User.objects.filter(id__in=ids).update(is_locked=False)
    return JsonResponse({'ok': True, 'unlocked': n})


# ═══════════════════════════════════════════════════════════
# 조직 관리 — 페이지 + API
# ═══════════════════════════════════════════════════════════

@super_admin_required
def organization_manage(request):
    """조직 관리 메인 페이지.
    초기 진입 시 회사(root) 가 펼쳐진 상태. 부서 선택 → 우측 상세는 AJAX.
    """
    company = Organization.objects.filter(parent__isnull=True).first()
    departments = []
    if company:
        departments = list(
            company.children.exclude(is_unassigned_bucket=True).order_by('sort_order')
        )
        unassigned = company.children.filter(is_unassigned_bucket=True).first()
        if unassigned:
            departments.append(unassigned)

    ctx = {
        'company'    : company,
        'departments': departments,
    }
    return render(request, 'backoffice/organizations/manage.html', ctx)


def _org_to_dict(org: Organization) -> dict:
    return {
        'id'          : org.id,
        'name'        : org.name,
        'code'        : org.code,
        'parent_id'   : org.parent_id,
        'description' : org.description,
        'leader_id'   : org.leader_id,
        'leader_name' : org.leader.first_name if org.leader else None,
        'is_unassigned_bucket': org.is_unassigned_bucket,
        'is_root'     : org.is_root,
        'member_count': org.member_count,
        'updated_at'  : org.updated_at.strftime('%Y-%m-%d %H:%M') if org.updated_at else '-',
        'updated_by_name': org.updated_by.first_name if org.updated_by else '-',
    }


@super_admin_required_api
@require_GET
def organization_detail_api(request, pk):
    org = get_object_or_404(Organization, pk=pk)
    members = org.users.select_related('position_obj').order_by('-id')
    members_data = [{
        'id'      : u.id,
        'name'    : u.first_name,
        'username': u.username,
        'position': u.display_position,
        'account_status'        : u.account_status,
        'account_status_display': u.account_status_display,
        'is_leader': (u.id == org.leader_id),
    } for u in members]

    return JsonResponse({
        'organization': _org_to_dict(org),
        'members'     : members_data,
    })


@super_admin_required_api
@require_POST
def organization_create_api(request):
    form = OrganizationForm(_parse_json(request))
    if not form.is_valid():
        return JsonResponse(
            {'ok': False, 'errors': _form_errors_payload(form)},
            status=400,
        )
    org = form.save(by=request.user)
    return JsonResponse({'ok': True, 'organization': _org_to_dict(org)})


@super_admin_required_api
@require_POST
def organization_update_api(request, pk):
    org = get_object_or_404(Organization, pk=pk)
    if org.is_unassigned_bucket:
        return JsonResponse(
            {'ok': False, 'error': '"조직 없음" 가상 부서는 수정할 수 없습니다.'},
            status=400,
        )
    form = OrganizationForm(_parse_json(request), instance=org)
    if not form.is_valid():
        return JsonResponse(
            {'ok': False, 'errors': _form_errors_payload(form)},
            status=400,
        )
    org = form.save(by=request.user)
    return JsonResponse({'ok': True, 'organization': _org_to_dict(org)})


@super_admin_required_api
@require_POST
def organization_delete_api(request, pk):
    """부서 삭제. 소속 사용자는 '조직 없음' 으로 자동 이동."""
    org = get_object_or_404(Organization, pk=pk)
    if org.is_unassigned_bucket:
        return JsonResponse(
            {'ok': False, 'error': '"조직 없음" 가상 부서는 삭제할 수 없습니다.'},
            status=400,
        )
    if org.is_root:
        return JsonResponse(
            {'ok': False, 'error': '회사(루트) 노드는 삭제할 수 없습니다.'},
            status=400,
        )
    # 소속 사용자 → 조직 없음 으로 이동
    company = org.parent
    bucket = company.children.filter(is_unassigned_bucket=True).first() if company else None
    if bucket:
        org.users.update(organization=bucket)

    org.delete()
    return JsonResponse({'ok': True})


@super_admin_required_api
@require_POST
def organization_assign_members_api(request, pk):
    """피그마 '구성원 추가' — 다른 부서 사용자를 이 부서로 옮김(또는 겸직).
    body: {"user_ids": [...], "keep_previous": false}
    keep_previous 는 v1 에서는 무시 (겸직 미지원, v2)
    """
    org = get_object_or_404(Organization, pk=pk)
    data = _parse_json(request)
    user_ids = data.get('user_ids') or []
    if not user_ids:
        return JsonResponse({'ok': False, 'error': '대상 없음'}, status=400)
    n = User.objects.filter(id__in=user_ids).update(
        organization=org,
        department=org.name,
    )
    return JsonResponse({'ok': True, 'assigned': n})


@super_admin_required_api
@require_POST
def organization_remove_members_api(request, pk):
    """피그마 '소속 제외' — 선택된 사용자를 '조직 없음' 으로."""
    org = get_object_or_404(Organization, pk=pk)
    user_ids = _parse_json(request).get('user_ids') or []
    if not user_ids:
        return JsonResponse({'ok': False, 'error': '대상 없음'}, status=400)
    company = org.parent if not org.is_root else org
    bucket = (
        company.children.filter(is_unassigned_bucket=True).first()
        if company else None
    )
    if not bucket:
        return JsonResponse(
            {'ok': False, 'error': '"조직 없음" 가상 부서를 찾을 수 없습니다.'},
            status=500,
        )
    n = User.objects.filter(id__in=user_ids, organization=org).update(
        organization=bucket,
        department=bucket.name,
    )
    return JsonResponse({'ok': True, 'removed': n})


@super_admin_required_api
@require_POST
def organization_set_leader_api(request, pk):
    """조직장 임명. body: {"user_id": ...}
    피그마: 다중 선택 시 비활성, 단건만 가능.
    """
    org = get_object_or_404(Organization, pk=pk)
    user_id = _parse_json(request).get('user_id')
    if not user_id:
        return JsonResponse({'ok': False, 'error': '대상 없음'}, status=400)
    try:
        u = User.objects.get(pk=user_id, organization=org)
    except User.DoesNotExist:
        return JsonResponse(
            {'ok': False, 'error': '해당 부서 소속 사용자만 조직장 지정 가능합니다.'},
            status=400,
        )
    org.leader = u
    org.updated_by = request.user
    org.save(update_fields=['leader', 'updated_by', 'updated_at'])
    return JsonResponse({'ok': True})


@super_admin_required_api
@require_GET
def organization_member_picker_api(request):
    """구성원 선택 팝업 — 부서별 구성원 목록 제공.
    GET ?org_id=<id> → 해당 부서 구성원 (이미 그 부서면 선택 불가)
    GET (org_id 없음) → 회사 전체 구성원
    """
    org_id = request.GET.get('org_id')
    qs = User.objects.select_related('organization', 'position_obj').order_by('first_name')
    target_org_id = None
    if org_id:
        try:
            target_org_id = int(org_id)
        except ValueError:
            target_org_id = None

    payload = [{
        'id'             : u.id,
        'name'           : u.first_name,
        'username'       : u.username,
        'position'       : u.display_position,
        'organization'   : u.display_organization,
        'organization_id': u.organization_id,
        'is_in_target'   : (u.organization_id == target_org_id) if target_org_id else False,
    } for u in qs]
    return JsonResponse({'users': payload})


# ═══════════════════════════════════════════════════════════
# 직위 관리 — 페이지 + API
# ═══════════════════════════════════════════════════════════

@super_admin_required
def position_list(request):
    q = request.GET.get('q', '').strip()
    qs = Position.objects.all()
    if q:
        qs = qs.filter(name__icontains=q)
    qs = qs.order_by('sort_order', 'name')
    return render(request, 'backoffice/positions/list.html', {
        'rows' : list(qs),
        'q'    : q,
    })


def _position_to_dict(p: Position) -> dict:
    return {
        'id'        : p.id,
        'name'      : p.name,
        'sort_order': p.sort_order,
        'is_active' : p.is_active,
        'description': p.description,
        'updated_at': p.updated_at.strftime('%Y-%m-%d %H:%M') if p.updated_at else '-',
    }


@super_admin_required_api
@require_GET
def position_detail_api(request, pk):
    p = get_object_or_404(Position, pk=pk)
    return JsonResponse({'position': _position_to_dict(p)})


@super_admin_required_api
@require_POST
def position_create_api(request):
    form = PositionForm(_parse_json(request))
    if not form.is_valid():
        return JsonResponse(
            {'ok': False, 'errors': _form_errors_payload(form)},
            status=400,
        )
    p = form.save(by=request.user)
    return JsonResponse({'ok': True, 'position': _position_to_dict(p)})


@super_admin_required_api
@require_POST
def position_update_api(request, pk):
    p = get_object_or_404(Position, pk=pk)
    form = PositionForm(_parse_json(request), instance=p)
    if not form.is_valid():
        return JsonResponse(
            {'ok': False, 'errors': _form_errors_payload(form)},
            status=400,
        )
    p = form.save(by=request.user)
    return JsonResponse({'ok': True, 'position': _position_to_dict(p)})


@super_admin_required_api
@require_POST
def position_bulk_delete_api(request):
    ids = _parse_json(request).get('ids') or []
    if not ids:
        return JsonResponse({'ok': False, 'error': '대상 없음'}, status=400)
    deleted, _ = Position.objects.filter(id__in=ids).delete()
    return JsonResponse({'ok': True, 'deleted': deleted})


# ═══════════════════════════════════════════════════════════
# 코어 마스터 — 공통 코드 / 위험 유형 / 위험 기준 / 임계치
# ═══════════════════════════════════════════════════════════
from .models import (
    CodeGroup, Code, RiskCategory, RiskType, AlarmLevel,
    ThresholdCategory, Threshold,
)
from .forms import (
    CodeGroupForm, CodeForm,
    RiskCategoryForm, RiskTypeForm,
    AlarmLevelForm,
    ThresholdCategoryForm, ThresholdForm,
)


# ───────────────── 공통 코드 ─────────────────

@super_admin_required
def code_manage(request):
    """공통 코드 관리 — 그룹 트리 + 그룹별 코드 목록.
    피그마와 동일한 좌(그룹) 우(코드 목록) 2-패널.
    """
    groups = list(CodeGroup.objects.all().order_by('sort_order', 'code'))
    return render(request, 'backoffice/codes/manage.html', {
        'groups': groups,
        'active_menu': 'codes',
    })


def _code_group_to_dict(g: CodeGroup) -> dict:
    return {
        'id': g.id, 'code': g.code, 'name': g.name,
        'description': g.description,
        'sort_order': g.sort_order, 'is_active': g.is_active,
        'is_system': g.is_system,
        'code_count': g.code_count,
        'updated_at': g.updated_at.strftime('%Y-%m-%d %H:%M') if g.updated_at else '-',
        'updated_by_name': g.updated_by.first_name if g.updated_by else '-',
    }

def _code_to_dict(c: Code) -> dict:
    return {
        'id': c.id, 'group_id': c.group_id,
        'code': c.code, 'name': c.name, 'description': c.description,
        'sort_order': c.sort_order, 'is_active': c.is_active,
        'updated_at': c.updated_at.strftime('%Y-%m-%d %H:%M') if c.updated_at else '-',
    }


@super_admin_required_api
@require_GET
def code_group_detail_api(request, pk):
    g = get_object_or_404(CodeGroup, pk=pk)
    codes = [_code_to_dict(c) for c in g.codes.order_by('sort_order', 'code')]
    return JsonResponse({'group': _code_group_to_dict(g), 'codes': codes})


@super_admin_required_api
@require_POST
def code_group_create_api(request):
    form = CodeGroupForm(_parse_json(request))
    if not form.is_valid():
        return JsonResponse({'ok': False, 'errors': _form_errors_payload(form)}, status=400)
    g = form.save(by=request.user)
    return JsonResponse({'ok': True, 'group': _code_group_to_dict(g)})


@super_admin_required_api
@require_POST
def code_group_update_api(request, pk):
    g = get_object_or_404(CodeGroup, pk=pk)
    form = CodeGroupForm(_parse_json(request), instance=g)
    if not form.is_valid():
        return JsonResponse({'ok': False, 'errors': _form_errors_payload(form)}, status=400)
    g = form.save(by=request.user)
    return JsonResponse({'ok': True, 'group': _code_group_to_dict(g)})


@super_admin_required_api
@require_POST
def code_group_delete_api(request, pk):
    g = get_object_or_404(CodeGroup, pk=pk)
    if g.is_system:
        return JsonResponse(
            {'ok': False, 'error': '시스템 코드 그룹은 삭제할 수 없습니다.'},
            status=400,
        )
    g.delete()
    return JsonResponse({'ok': True})


@super_admin_required_api
@require_POST
def code_create_api(request):
    form = CodeForm(_parse_json(request))
    if not form.is_valid():
        return JsonResponse({'ok': False, 'errors': _form_errors_payload(form)}, status=400)
    c = form.save(by=request.user)
    return JsonResponse({'ok': True, 'code': _code_to_dict(c)})


@super_admin_required_api
@require_POST
def code_update_api(request, pk):
    c = get_object_or_404(Code, pk=pk)
    form = CodeForm(_parse_json(request), instance=c)
    if not form.is_valid():
        return JsonResponse({'ok': False, 'errors': _form_errors_payload(form)}, status=400)
    c = form.save(by=request.user)
    return JsonResponse({'ok': True, 'code': _code_to_dict(c)})


@super_admin_required_api
@require_POST
def code_bulk_delete_api(request):
    ids = _parse_json(request).get('ids') or []
    if not ids:
        return JsonResponse({'ok': False, 'error': '대상 없음'}, status=400)
    deleted, _ = Code.objects.filter(id__in=ids).delete()
    return JsonResponse({'ok': True, 'deleted': deleted})


@super_admin_required_api
@require_POST
def code_bulk_toggle_api(request):
    """is_active 일괄 변경. body: {"ids": [...], "is_active": false}"""
    data = _parse_json(request)
    ids = data.get('ids') or []
    target = bool(data.get('is_active'))
    if not ids:
        return JsonResponse({'ok': False, 'error': '대상 없음'}, status=400)
    n = Code.objects.filter(id__in=ids).update(is_active=target)
    return JsonResponse({'ok': True, 'updated': n})


# ───────────────── 위험 유형 ─────────────────

@super_admin_required
def risk_manage(request):
    cats = list(RiskCategory.objects.all().order_by('sort_order', 'code'))
    return render(request, 'backoffice/risks/manage.html', {
        'categories': cats,
        'active_menu': 'risks',
    })


def _risk_cat_to_dict(c: RiskCategory) -> dict:
    return {
        'id': c.id, 'code': c.code, 'name': c.name,
        'description': c.description,
        'applies_to': c.applies_to, 'applies_to_list': c.applies_to_list,
        'sort_order': c.sort_order, 'is_active': c.is_active,
        'is_system': c.is_system, 'type_count': c.type_count,
        'updated_at': c.updated_at.strftime('%Y-%m-%d %H:%M') if c.updated_at else '-',
        'updated_by_name': c.updated_by.first_name if c.updated_by else '-',
    }

def _risk_type_to_dict(t: RiskType) -> dict:
    return {
        'id': t.id, 'category_id': t.category_id,
        'code': t.code, 'name': t.name, 'description': t.description,
        'show_on_map': t.show_on_map,
        'sort_order': t.sort_order, 'is_active': t.is_active,
        'updated_at': t.updated_at.strftime('%Y-%m-%d %H:%M') if t.updated_at else '-',
    }


@super_admin_required_api
@require_GET
def risk_cat_detail_api(request, pk):
    c = get_object_or_404(RiskCategory, pk=pk)
    types = [_risk_type_to_dict(t) for t in c.types.order_by('sort_order', 'code')]
    return JsonResponse({'category': _risk_cat_to_dict(c), 'types': types})


@super_admin_required_api
@require_POST
def risk_cat_create_api(request):
    form = RiskCategoryForm(_parse_json(request))
    if not form.is_valid():
        return JsonResponse({'ok': False, 'errors': _form_errors_payload(form)}, status=400)
    c = form.save(by=request.user)
    return JsonResponse({'ok': True, 'category': _risk_cat_to_dict(c)})


@super_admin_required_api
@require_POST
def risk_cat_update_api(request, pk):
    c = get_object_or_404(RiskCategory, pk=pk)
    form = RiskCategoryForm(_parse_json(request), instance=c)
    if not form.is_valid():
        return JsonResponse({'ok': False, 'errors': _form_errors_payload(form)}, status=400)
    c = form.save(by=request.user)
    return JsonResponse({'ok': True, 'category': _risk_cat_to_dict(c)})


@super_admin_required_api
@require_POST
def risk_cat_delete_api(request, pk):
    c = get_object_or_404(RiskCategory, pk=pk)
    if c.is_system:
        return JsonResponse({'ok': False, 'error': '시스템 분류는 삭제할 수 없습니다.'}, status=400)
    c.delete()
    return JsonResponse({'ok': True})


@super_admin_required_api
@require_POST
def risk_type_create_api(request):
    form = RiskTypeForm(_parse_json(request))
    if not form.is_valid():
        return JsonResponse({'ok': False, 'errors': _form_errors_payload(form)}, status=400)
    t = form.save(by=request.user)
    return JsonResponse({'ok': True, 'type': _risk_type_to_dict(t)})


@super_admin_required_api
@require_POST
def risk_type_update_api(request, pk):
    t = get_object_or_404(RiskType, pk=pk)
    form = RiskTypeForm(_parse_json(request), instance=t)
    if not form.is_valid():
        return JsonResponse({'ok': False, 'errors': _form_errors_payload(form)}, status=400)
    t = form.save(by=request.user)
    return JsonResponse({'ok': True, 'type': _risk_type_to_dict(t)})


@super_admin_required_api
@require_POST
def risk_type_bulk_delete_api(request):
    ids = _parse_json(request).get('ids') or []
    if not ids:
        return JsonResponse({'ok': False, 'error': '대상 없음'}, status=400)
    deleted, _ = RiskType.objects.filter(id__in=ids).delete()
    return JsonResponse({'ok': True, 'deleted': deleted})


# ───────────────── 위험 기준 (알람 단계) ─────────────────

@super_admin_required
def alarm_level_list(request):
    rows = list(AlarmLevel.objects.all().order_by('priority', 'code'))
    return render(request, 'backoffice/alarm_levels/list.html', {
        'rows': rows,
        'active_menu': 'alarm_levels',
    })


def _alarm_to_dict(a: AlarmLevel) -> dict:
    return {
        'id': a.id, 'code': a.code, 'name': a.name,
        'color': a.color, 'color_display': a.get_color_display(),
        'intensity': a.intensity, 'intensity_display': a.get_intensity_display(),
        'priority': a.priority, 'description': a.description,
        'is_active': a.is_active, 'is_system': a.is_system,
        'updated_at': a.updated_at.strftime('%Y-%m-%d %H:%M') if a.updated_at else '-',
    }


@super_admin_required_api
@require_GET
def alarm_level_detail_api(request, pk):
    a = get_object_or_404(AlarmLevel, pk=pk)
    return JsonResponse({'alarm_level': _alarm_to_dict(a)})


@super_admin_required_api
@require_POST
def alarm_level_create_api(request):
    form = AlarmLevelForm(_parse_json(request))
    if not form.is_valid():
        return JsonResponse({'ok': False, 'errors': _form_errors_payload(form)}, status=400)
    a = form.save(by=request.user)
    return JsonResponse({'ok': True, 'alarm_level': _alarm_to_dict(a)})


@super_admin_required_api
@require_POST
def alarm_level_update_api(request, pk):
    a = get_object_or_404(AlarmLevel, pk=pk)
    form = AlarmLevelForm(_parse_json(request), instance=a)
    if not form.is_valid():
        return JsonResponse({'ok': False, 'errors': _form_errors_payload(form)}, status=400)
    a = form.save(by=request.user)
    return JsonResponse({'ok': True, 'alarm_level': _alarm_to_dict(a)})


@super_admin_required_api
@require_POST
def alarm_level_bulk_delete_api(request):
    ids = _parse_json(request).get('ids') or []
    if not ids:
        return JsonResponse({'ok': False, 'error': '대상 없음'}, status=400)
    # 시스템 레벨 보호
    sys_ids = list(
        AlarmLevel.objects.filter(id__in=ids, is_system=True).values_list('id', flat=True)
    )
    if sys_ids:
        return JsonResponse(
            {'ok': False, 'error': f'시스템 단계 {len(sys_ids)}개는 삭제할 수 없습니다.'},
            status=400,
        )
    deleted, _ = AlarmLevel.objects.filter(id__in=ids).delete()
    return JsonResponse({'ok': True, 'deleted': deleted})


# ───────────────── 임계치 기준 ─────────────────

@super_admin_required
def threshold_manage(request):
    cats = list(ThresholdCategory.objects.all().order_by('sort_order', 'code'))
    return render(request, 'backoffice/thresholds/manage.html', {
        'categories': cats,
        'active_menu': 'thresholds',
    })


def _th_cat_to_dict(c: ThresholdCategory) -> dict:
    return {
        'id': c.id, 'code': c.code, 'name': c.name,
        'description': c.description,
        'applies_to': c.applies_to, 'applies_to_list': c.applies_to_list,
        'sort_order': c.sort_order, 'is_active': c.is_active,
        'is_system': c.is_system, 'threshold_count': c.threshold_count,
        'updated_at': c.updated_at.strftime('%Y-%m-%d %H:%M') if c.updated_at else '-',
        'updated_by_name': c.updated_by.first_name if c.updated_by else '-',
    }

def _th_to_dict(t: Threshold) -> dict:
    return {
        'id': t.id, 'category_id': t.category_id,
        'item_code': t.item_code, 'item_name': t.item_name,
        'unit': t.unit,
        'operator': t.operator, 'operator_display': t.get_operator_display(),
        'caution_value': t.caution_value, 'danger_value': t.danger_value,
        'is_active': t.is_active,
        'applies_to': t.applies_to, 'applies_to_list': t.applies_to_list,
        'description': t.description,
        'updated_at': t.updated_at.strftime('%Y-%m-%d %H:%M') if t.updated_at else '-',
    }


@super_admin_required_api
@require_GET
def threshold_cat_detail_api(request, pk):
    c = get_object_or_404(ThresholdCategory, pk=pk)
    items = [_th_to_dict(t) for t in c.thresholds.order_by('item_code')]
    return JsonResponse({'category': _th_cat_to_dict(c), 'thresholds': items})


@super_admin_required_api
@require_POST
def threshold_cat_create_api(request):
    form = ThresholdCategoryForm(_parse_json(request))
    if not form.is_valid():
        return JsonResponse({'ok': False, 'errors': _form_errors_payload(form)}, status=400)
    c = form.save(by=request.user)
    return JsonResponse({'ok': True, 'category': _th_cat_to_dict(c)})


@super_admin_required_api
@require_POST
def threshold_cat_update_api(request, pk):
    c = get_object_or_404(ThresholdCategory, pk=pk)
    form = ThresholdCategoryForm(_parse_json(request), instance=c)
    if not form.is_valid():
        return JsonResponse({'ok': False, 'errors': _form_errors_payload(form)}, status=400)
    c = form.save(by=request.user)
    return JsonResponse({'ok': True, 'category': _th_cat_to_dict(c)})


@super_admin_required_api
@require_POST
def threshold_create_api(request):
    form = ThresholdForm(_parse_json(request))
    if not form.is_valid():
        return JsonResponse({'ok': False, 'errors': _form_errors_payload(form)}, status=400)
    t = form.save(by=request.user)
    return JsonResponse({'ok': True, 'threshold': _th_to_dict(t)})


@super_admin_required_api
@require_POST
def threshold_update_api(request, pk):
    t = get_object_or_404(Threshold, pk=pk)
    form = ThresholdForm(_parse_json(request), instance=t)
    if not form.is_valid():
        return JsonResponse({'ok': False, 'errors': _form_errors_payload(form)}, status=400)
    t = form.save(by=request.user)
    return JsonResponse({'ok': True, 'threshold': _th_to_dict(t)})


@super_admin_required_api
@require_POST
def threshold_bulk_delete_api(request):
    ids = _parse_json(request).get('ids') or []
    if not ids:
        return JsonResponse({'ok': False, 'error': '대상 없음'}, status=400)
    deleted, _ = Threshold.objects.filter(id__in=ids).delete()
    return JsonResponse({'ok': True, 'deleted': deleted})


@super_admin_required_api
@require_POST
def threshold_bulk_toggle_api(request):
    data = _parse_json(request)
    ids = data.get('ids') or []
    target = bool(data.get('is_active'))
    if not ids:
        return JsonResponse({'ok': False, 'error': '대상 없음'}, status=400)
    n = Threshold.objects.filter(id__in=ids).update(is_active=target)
    return JsonResponse({'ok': True, 'updated': n})


# ───────────────── FastAPI 동기화용 내부 API ─────────────────
#
# /dashboard/api/thresholds/  →  FastAPI 가 호출하여 GAS_THRESHOLDS 대체
#
# 인증: 세션 인증 (Django) 또는 INTERNAL_API_KEY (FastAPI 가 호출 시).
# 응답 포맷: 기존 GAS_THRESHOLDS 와 호환되는 dict 구조 + 추가 메타.

from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
@require_GET
def thresholds_for_fastapi(request):
    """FastAPI 가 startup / 주기 갱신 시 호출하는 동기화 엔드포인트.

    InternalAPIKeyMiddleware 가 internal key 또는 세션 인증을 통과시킴.
    응답:
      {
        "categories": {
          "TH_GAS": {
            "code": "TH_GAS", "name": "유해가스",
            "applies_to": ["realtime", "alarm"],
            "thresholds": [ {item_code, item_name, unit, operator, caution, danger, applies_to}, ... ]
          },
          ...
        },
        "flat": { item_code: {...같은 entry...}, ... }   # generators.py 직접 lookup 용
      }
    """
    cats = ThresholdCategory.objects.filter(is_active=True).prefetch_related('thresholds')
    payload = {'categories': {}, 'flat': {}}
    for cat in cats:
        cat_obj = {
            'code': cat.code, 'name': cat.name,
            'applies_to': cat.applies_to_list,
            'thresholds': [],
        }
        for t in cat.thresholds.filter(is_active=True):
            entry = {
                'category_code': cat.code,
                'item_code': t.item_code, 'item_name': t.item_name,
                'unit': t.unit, 'operator': t.operator,
                'caution': t.caution_value, 'danger': t.danger_value,
                'applies_to': t.applies_to_list,
            }
            cat_obj['thresholds'].append(entry)
            # flat 은 (category_code, item_code) 조합 키 — 다른 카테고리에 같은 item_code 가 있을 수 있으므로
            payload['flat'][f'{cat.code}.{t.item_code}'] = entry

        payload['categories'][cat.code] = cat_obj

    return JsonResponse(payload)
